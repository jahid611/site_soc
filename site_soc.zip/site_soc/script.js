// Définition des produits
const products = [
    { id: 1, name: 'Maillot Domicile', price: 89.99, image: '/placeholder.svg?height=200&width=200', category: 'Maillots' },
    { id: 2, name: 'Maillot Extérieur', price: 89.99, image: '/placeholder.svg?height=200&width=200', category: 'Maillots' },
    { id: 3, name: 'Ballon Officiel', price: 29.99, image: '/placeholder.svg?height=200&width=200', category: 'Équipement' },
    { id: 4, name: 'Écharpe de Supporter', price: 19.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 5, name: 'Maillot Third', price: 89.99, image: '/placeholder.svg?height=200&width=200', category: 'Maillots' },
    { id: 6, name: 'Short Domicile', price: 39.99, image: '/placeholder.svg?height=200&width=200', category: 'Vêtements' },
    { id: 7, name: 'Chaussettes Officielles', price: 14.99, image: '/placeholder.svg?height=200&width=200', category: 'Vêtements' },
    { id: 8, name: 'Veste d\'Entraînement', price: 79.99, image: '/placeholder.svg?height=200&width=200', category: 'Vêtements' },
    { id: 9, name: 'Pantalon d\'Entraînement', price: 59.99, image: '/placeholder.svg?height=200&width=200', category: 'Vêtements' },
    { id: 10, name: 'Casquette Real Madrid', price: 24.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 11, name: 'Gants de Gardien', price: 34.99, image: '/placeholder.svg?height=200&width=200', category: 'Équipement' },
    { id: 12, name: 'Sac à Dos Officiel', price: 49.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 13, name: 'Mug Real Madrid', price: 12.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 14, name: 'Porte-clés Logo', price: 9.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 15, name: 'Drapeau Real Madrid', price: 19.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 16, name: 'Livre Histoire du Club', price: 29.99, image: '/placeholder.svg?height=200&width=200', category: 'Livres' },
    { id: 17, name: 'Poster Équipe', price: 14.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 18, name: 'Bracelet Silicone', price: 7.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 19, name: 'Serviette de Bain', price: 29.99, image: '/placeholder.svg?height=200&width=200', category: 'Accessoires' },
    { id: 20, name: 'Ballon Mini', price: 19.99, image: '/placeholder.svg?height=200&width=200', category: 'Équipement' },
];

// Gestion du panier
let cart = [];

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        updateCartDisplay();
        saveCartToLocalStorage();
        animateCartIcon();
    }
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartDisplay();
    saveCartToLocalStorage();
}

function updateCartQuantity(productId, newQuantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = parseInt(newQuantity);
        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            updateCartDisplay();
            saveCartToLocalStorage();
        }
    }
}

function updateCartDisplay() {
    const cartContainer = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    const cartCount = document.getElementById('cart-count');

    if (cartContainer) {
        cartContainer.innerHTML = '';
        let total = 0;

        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}" width="50" height="50">
                <span>${item.name}</span>
                <input type="number" value="${item.quantity}" min="1" data-id="${item.id}" class="cart-quantity">
                <span>${formatCurrency(item.price * item.quantity)}</span>
                <button class="remove-from-cart" data-id="${item.id}">Supprimer</button>
            `;
            cartContainer.appendChild(itemElement);

            total += item.price * item.quantity;
        });

        if (cartTotal) {
            cartTotal.textContent = formatCurrency(total);
        }
    }

    if (cartCount) {
        const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = itemCount;
    }
}

function saveCartToLocalStorage() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function loadCartFromLocalStorage() {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartDisplay();
    }
}

// Affichage des produits
function displayProducts(productsToDisplay = products) {
    const productsContainer = document.getElementById('products-container');
    if (productsContainer) {
        productsContainer.innerHTML = '';
        productsToDisplay.forEach(product => {
            const productElement = document.createElement('div');
            productElement.className = 'product-item';
            productElement.innerHTML = `
                <img src="${product.image}" alt="${product.name}" width="200" height="200">
                <h3>${product.name}</h3>
                <p>${formatCurrency(product.price)}</p>
                <button class="add-to-cart" data-id="${product.id}">Ajouter au panier</button>
            `;
            productsContainer.appendChild(productElement);
        });
    }
}

// Filtrage des produits
function filterProducts(category) {
    const filteredProducts = category === 'Tous' 
        ? products 
        : products.filter(product => product.category === category);
    displayProducts(filteredProducts);
}

// Recherche de produits
const searchProducts = debounce((query) => {
    const searchResults = products.filter(product => 
        product.name.toLowerCase().includes(query.toLowerCase())
    );
    displayProducts(searchResults);
}, 300);

// Gestion de la navigation
function navigateTo(page) {
    history.pushState(null, '', `#${page}`);
    updateContent(page);
}

function updateContent(page) {
    const mainContent = document.getElementById('main-content');
    if (mainContent) {
        switch(page) {
            case 'home':
                mainContent.innerHTML = `
                    <h1>Bienvenue sur la boutique officielle du Real Madrid</h1>
                    <p>Découvrez notre sélection de produits officiels pour supporter votre équipe préférée.</p>
                    <a href="#products" onclick="navigateTo('products'); return false;">Voir tous les produits</a>
                `;
                break;
            case 'products':
                mainContent.innerHTML = `
                    <h2>Nos Produits</h2>
                    <div id="category-filter">
                        <button onclick="filterProducts('Tous')">Tous</button>
                        <button onclick="filterProducts('Maillots')">Maillots</button>
                        <button onclick="filterProducts('Vêtements')">Vêtements</button>
                        <button onclick="filterProducts('Équipement')">Équipement</button>
                        <button onclick="filterProducts('Accessoires')">Accessoires</button>
                    </div>
                    <div id="products-container"></div>
                `;
                displayProducts();
                break;
            case 'cart':
                mainContent.innerHTML = `
                    <h2>Votre Panier</h2>
                    <div id="cart-items"></div>
                    <p>Total: <span id="cart-total"></span></p>
                    <button onclick="checkout()">Passer la commande</button>
                `;
                updateCartDisplay();
                break;
            default:
                mainContent.innerHTML = '<p>Page non trouvée</p>';
        }
    }
}

// Processus de paiement
function checkout() {
    if (cart.length === 0) {
        alert('Votre panier est vide');
        return;
    }

    const mainContent = document.getElementById('main-content');
    if (mainContent) {
        mainContent.innerHTML = `
            <h2>Finaliser votre commande</h2>
            <form id="checkout-form">
                <label for="name">Nom complet:</label>
                <input type="text" id="name" required>

                <label for="email">Email:</label>
                <input type="email" id="email" required>

                <label for="address">Adresse de livraison:</label>
                <textarea id="address" required></textarea>

                <label for="card">Numéro de carte bancaire:</label>
                <input type="text" id="card" required pattern="[0-9]{16}" title="Veuillez entrer un numéro de carte valide à 16 chiffres">

                <button type="submit">Payer</button>
            </form>
        `;

        const checkoutForm = document.getElementById('checkout-form');
        if (checkoutForm) {
            checkoutForm.addEventListener('submit', function(e) {
                e.preventDefault();
                processPayment();
            });
        }
    }
}

function processPayment() {
    // Simulation d'un processus de paiement
    showLoadingIndicator();
    setTimeout(() => {
        hideLoadingIndicator();
        alert('Paiement effectué avec succès! Merci pour votre achat.');
        cart = [];
        saveCartToLocalStorage();
        navigateTo('home');
    }, 2000);
}

// Gestion des événements
document.addEventListener('DOMContentLoaded', function() {
    loadCartFromLocalStorage();
    //Initial page load
    const initialPage = location.hash.slice(1) || 'home';
    updateContent(initialPage);

    // Gestion du clic sur les boutons "Ajouter au panier"
    document.body.addEventListener('click', function(e) {
        if (e.target.classList.contains('add-to-cart')) {
            const productId = parseInt(e.target.getAttribute('data-id'));
            addToCart(productId);
        }
    });

    // Gestion du clic sur les boutons "Supprimer du panier"
    document.body.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-from-cart')) {
            const productId = parseInt(e.target.getAttribute('data-id'));
            removeFromCart(productId);
        }
    });

    // Gestion du changement de quantité dans le panier
    document.body.addEventListener('change', function(e) {
        if (e.target.classList.contains('cart-quantity')) {
            const productId = parseInt(e.target.getAttribute('data-id'));
            const newQuantity = e.target.value;
            updateCartQuantity(productId, newQuantity);
        }
    });

    // Gestion de la recherche
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            searchProducts(e.target.value);
        });
    }

    // Update navigation links
    document.body.addEventListener('click', function(e) {
        if (e.target.tagName === 'A' && e.target.getAttribute('href').startsWith('#')) {
            e.preventDefault();
            const page = e.target.getAttribute('href').slice(1);
            navigateTo(page);
        }
    });

    // Handle back/forward browser buttons
    window.addEventListener('popstate', function() {
        const page = location.hash.slice(1) || 'home';
        updateContent(page);
    });


    setupInfiniteScroll();
    lazyLoadImages();
    improveAccessibility();
    setupAnimations();
    checkCookieConsent();
});

// Fonctions utilitaires
function formatCurrency(amount) {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
}

function debounce(func, delay) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}

// Animation du panier
function animateCartIcon() {
    const cartIcon = document.getElementById('cart-icon');
    if (cartIcon) {
        cartIcon.classList.add('cart-animation');
        setTimeout(() => cartIcon.classList.remove('cart-animation'), 500);
    }
}

// Gestion du scroll infini pour les produits
let currentPage = 1;
const productsPerPage = 10;

function loadMoreProducts() {
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const newProducts = products.slice(startIndex, endIndex);

    const productsContainer = document.getElementById('products-container');
    if (productsContainer && newProducts.length > 0) {
        newProducts.forEach(product => {
            const productElement = document.createElement('div');
            productElement.className = 'product-item';
            productElement.innerHTML = `
                <img src="${product.image}" alt="${product.name}" width="200" height="200">
                <h3>${product.name}</h3>
                <p>${formatCurrency(product.price)}</p>
                <button class="add-to-cart" data-id="${product.id}">Ajouter au panier</button>
            `;
            productsContainer.appendChild(productElement);
        });
        currentPage++;
    }
}

// Observateur d'intersection pour le scroll infini
const intersectionObserver = new IntersectionObserver(entries => {
    if (entries[0].intersectionRatio <= 0) return;
    loadMoreProducts();
});



// Fonction pour initialiser l'observateur
function setupInfiniteScroll() {
    const sentinel = document.createElement('div');
    sentinel.id = 'sentinel';
    const productsContainer = document.getElementById('products-container');
    if (productsContainer) {
        productsContainer.appendChild(sentinel);
        intersectionObserver.observe(sentinel);
    }
}

// Gestion du mode sombre
let isDarkMode = false;

function toggleDarkMode() {
    isDarkMode = !isDarkMode;
    document.body.classList.toggle('dark-mode', isDarkMode);
    localStorage.setItem('darkMode', isDarkMode);
}

// Chargement de la préférence de mode sombre
function loadDarkModePreference() {
    const savedMode = localStorage.getItem('darkMode');
    if (savedMode !== null) {
        isDarkMode = JSON.parse(savedMode);
        document.body.classList.toggle('dark-mode', isDarkMode);
    }
}

// Gestion des erreurs
function handleError(error) {
    console.error('Une erreur est survenue:', error);
    const errorContainer = document.getElementById('error-container');
    if (errorContainer) {
        errorContainer.textContent = 'Une erreur est survenue. Veuillez réessayer plus tard.';
        errorContainer.style.display = 'block';
    }
}

// Wrap des appels API avec gestion d'erreurs
async function fetchWithErrorHandling(url, options = {}) {
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        handleError(error);
    }
}

// Gestion de la performance
const performanceMetrics = {
    pageLoadTime: 0,
    firstContentfulPaint: 0,
    timeToInteractive: 0
};

function measurePerformance() {
    performanceMetrics.pageLoadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;

    const paintEntries = performance.getEntriesByType('paint');
    const firstContentfulPaint = paintEntries.find(entry => entry.name === 'first-contentful-paint');
    if (firstContentfulPaint) {
        performanceMetrics.firstContentfulPaint = firstContentfulPaint.startTime;
    }

    // Mesure approximative du Time to Interactive
    performanceMetrics.timeToInteractive = performance.now();

    console.log('Performance Metrics:', performanceMetrics);
}

window.addEventListener('load', measurePerformance);

// Lazy loading des images
function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.getAttribute('data-src');
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Gestion des cookies
function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = "expires=" + date.toUTCString();
    document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

function getCookie(name) {
    const cookieName = name + "=";
    const decodedCookie = decodeURIComponent(document.cookie);
    const cookieArray = decodedCookie.split(';');
    for (let i = 0; i < cookieArray.length; i++) {
        let cookie = cookieArray[i];
        while (cookie.charAt(0) === ' ') {
            cookie = cookie.substring(1);
        }
        if (cookie.indexOf(cookieName) === 0) {
            return cookie.substring(cookieName.length, cookie.length);
        }
    }
    return "";
}

// Exemple d'utilisation des cookies pour le consentement RGPD
function checkCookieConsent() {
    const consent = getCookie("cookieConsent");
    if (consent === "") {
        displayCookieConsentBanner();
    }
}

function displayCookieConsentBanner() {
    const banner = document.createElement('div');
    banner.id = 'cookie-consent-banner';
    banner.innerHTML = `
        <p>Nous utilisons des cookies pour améliorer votre expérience sur notre site. En continuant à naviguer, vous acceptez notre utilisation des cookies.</p>
        <button id="accept-cookies">Accepter</button>
        <button id="reject-cookies">Refuser</button>
    `;
    document.body.appendChild(banner);

    document.getElementById('accept-cookies').addEventListener('click', () => {
        setCookie("cookieConsent", "accepted", 365);
        banner.remove();
    });

    document.getElementById('reject-cookies').addEventListener('click', () => {
        setCookie("cookieConsent", "rejected", 365);
        banner.remove();
    });
}

// Gestion de l'accessibilité
function improveAccessibility() {
    // Ajout d'attributs ARIA
    document.querySelectorAll('button').forEach(button => {
        if (!button.getAttribute('aria-label')) {
            button.setAttribute('aria-label', button.textContent.trim());
        }
    });

    // Amélioration du contraste
    document.querySelectorAll('.low-contrast').forEach(element => {
        element.classList.remove('low-contrast');
        element.classList.add('high-contrast');
    });

    // Ajout de focus visible
    const style = document.createElement('style');
    style.textContent = `
        *:focus {
            outline: 2px solid #007bff;
            outline-offset: 2px;
        }
    `;
    document.head.appendChild(style);
}

// Gestion des animations
function setupAnimations() {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    const animationObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
            }
        });
    });

    animatedElements.forEach(el => animationObserver.observe(el));
}

// Initialisation de l'application
function initApp() {
    loadCartFromLocalStorage();
    loadDarkModePreference();
    //Initial page load
    const initialPage = location.hash.slice(1) || 'home';
    updateContent(initialPage);
    setupInfiniteScroll();
    lazyLoadImages();
    improveAccessibility();
    setupAnimations();
    checkCookieConsent();
}

// Lancement de l'initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', initApp);

// Indicateur de chargement
function showLoadingIndicator() {
    const loadingIndicator = document.createElement('div');
    loadingIndicator.id = 'loading-indicator';
    loadingIndicator.textContent = 'Chargement...';
    document.body.appendChild(loadingIndicator);
}

function hideLoadingIndicator() {
    const loadingIndicator = document.getElementById('loading-indicator');
    if (loadingIndicator) {
        loadingIndicator.remove();
    }
}